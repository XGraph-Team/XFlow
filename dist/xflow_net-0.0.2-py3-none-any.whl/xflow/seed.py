import numpy as np
import torch_geometric.datasets as ds
import random
import ndlib.models.epidemics as ep
import ndlib.models.ModelConfig as mc

def random(seed):
    random.seed(seed)
    np.random.seed(seed)
    return seed

def degree():
    return 

def eigen():
    return 